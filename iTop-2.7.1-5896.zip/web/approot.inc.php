<?php

define('APPROOT', dirname(__FILE__).'/');
define('APPCONF', APPROOT.'conf/');

require_once APPROOT.'bootstrap.inc.php';
